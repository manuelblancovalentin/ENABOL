#ifndef AUTOGRAD_DEFINES_H_
#define AUTOGRAD_DEFINES_H_

// [@manuelbv]: Added learning rate here
#define LEARNING_RATE 0.01
#define BATCH_SIZE 4

#endif
