//Numpy array shape [1, 2]
//Min 0.000000000000
//Max 0.218750000000
//Number of zeros 1

#ifndef W2_H_
#define W2_H_

#ifndef __SYNTHESIS__
weight2_t w2[2];
#else
weight2_t w2[2] = {0.21875, 0.00000};
#endif

#endif
