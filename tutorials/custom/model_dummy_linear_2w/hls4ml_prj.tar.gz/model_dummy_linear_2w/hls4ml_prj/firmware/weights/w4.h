//Numpy array shape [2, 1]
//Min -0.468750000000
//Max 0.000000000000
//Number of zeros 1

#ifndef W4_H_
#define W4_H_

#ifndef __SYNTHESIS__
weight4_t w4[2];
#else
weight4_t w4[2] = {0.00000, -0.46875};
#endif

#endif
