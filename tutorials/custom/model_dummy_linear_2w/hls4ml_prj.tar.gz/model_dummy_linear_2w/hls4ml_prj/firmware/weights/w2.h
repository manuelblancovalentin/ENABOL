//Numpy array shape [1, 2]
//Min -0.437500000000
//Max 0.000000000000
//Number of zeros 1

#ifndef W2_H_
#define W2_H_

#ifndef __SYNTHESIS__
weight2_t w2[2];
#else
weight2_t w2[2] = {0.00000, -0.43750};
#endif

#endif
