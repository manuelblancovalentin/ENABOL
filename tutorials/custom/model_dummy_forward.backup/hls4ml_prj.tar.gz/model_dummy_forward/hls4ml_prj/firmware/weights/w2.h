//Numpy array shape [1, 1]
//Min 0.500000000000
//Max 0.500000000000
//Number of zeros 0

#ifndef W2_H_
#define W2_H_

#ifndef __SYNTHESIS__
weight2_t w2[1];
#else
weight2_t w2[1] = {0.50000};
#endif

#endif
